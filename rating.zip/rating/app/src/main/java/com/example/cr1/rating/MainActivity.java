package com.example.cr1.rating;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {
    private RatingBar ratingBar;
    private String rating;
    public int data;
    private Button button;
    private ImageButton b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        b1 = findViewById(R.id.imageButton);
        ratingBar = findViewById(R.id.ratingBar);


        //button.setOnClickListener(this);
        //b1.setOnClickListener(this);

    }

    public void rate(View view) {
        rating = String.valueOf(ratingBar.getRating());
  if ((rating.equalsIgnoreCase("1.0"))) {
                Toast.makeText(getBaseContext(), "Dissatisfied Rating " +rating, Toast.LENGTH_LONG).show();
                Toast.makeText(getBaseContext(), " Thanks for rating  :-)", Toast.LENGTH_LONG).show();
            } else if ( rating.equalsIgnoreCase("2.0")) {
                Toast.makeText(getBaseContext(), "Below Average Rating " + rating, Toast.LENGTH_LONG).show();
                Toast.makeText(getBaseContext(), " Thanks for rating  :-)", Toast.LENGTH_LONG).show();

            } else if ( rating.equalsIgnoreCase("3.0")) {
                Toast.makeText(getBaseContext(), "Average Rating " + rating, Toast.LENGTH_LONG).show();
                Toast.makeText(getBaseContext(), " Thanks for rating  :-)", Toast.LENGTH_LONG).show();

            } else if ( rating.equalsIgnoreCase("4.0")) {
                Toast.makeText(getBaseContext(), "Satisfied Rating " + rating, Toast.LENGTH_LONG).show();
                Toast.makeText(getBaseContext(), " Thanks for rating  :-)", Toast.LENGTH_LONG).show();

            } else if ( rating.equalsIgnoreCase("5.0")) {
                Toast.makeText(getBaseContext(), "Ex-ordinary Rating " + data, Toast.LENGTH_LONG).show();
                Toast.makeText(getBaseContext(), " Thanks for rating  :-)", Toast.LENGTH_LONG).show();

            }

        }
    }






